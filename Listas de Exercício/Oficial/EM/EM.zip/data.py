import pandas as pd


wine_data = pd.read_csv('/home/wallace_nascimento/2020_3/Machine Learning/Listas de Exercício/Farias/q2'
                        '/wine.csv', header=None)
wine_data = wine_data.rename(columns=wine_data.iloc[0]).iloc[1:]